# Nutrifit Fitness App

## Project Overview
A modern fitness and nutrition tracking mobile application built with Flutter for the frontend and Python Flask for the backend. This is a college demo application focusing primarily on the user interface and frontend experience.

**Purpose**: Demonstrate a complete fitness app UI with login, workout tracking, diet planning, and progress monitoring features.

**Current State**: Fully functional frontend with all UI screens implemented. Backend structure is in place with basic demo routes.

## Recent Changes
- **October 15, 2025**: Initial project setup and complete implementation
  - Installed Flutter SDK 3.32.0 and Python Flask 3.1.2
  - Created complete Flutter app structure with all screens
  - Implemented login and signup pages with modern gradient design and form validation
  - Added comprehensive form validation with error messages and loading states
  - Built comprehensive dashboard with workout, diet, and AI recommendation sections
  - Added bottom navigation with 5 pages (Home, Workouts, Diet, Progress, Profile)
  - Applied green (#4CAF50) and white color theme throughout
  - Created basic Flask backend with demo routes (main.py)
  - Set up Flutter web workflow running on port 5000
  - All validation features working: email format, password strength, password matching

## Project Architecture

### Frontend (Flutter)
- **Framework**: Flutter 3.32.0 with Dart 3.8.0
- **Platform**: Web (running on port 5000)
- **Theme**: Material Design 3 with green (#4CAF50) primary color
- **Navigation**: Bottom navigation bar with 5 main sections

#### Screen Structure
```
lib/
├── main.dart                 # App entry point
└── screens/
    ├── login_page.dart       # Login screen with email/password
    ├── signup_page.dart      # Signup screen with form validation UI
    ├── dashboard_page.dart   # Main dashboard with all sections
    ├── workouts_page.dart    # Workout plans and exercises
    ├── diet_page.dart        # Diet tracking and meal plans
    ├── progress_page.dart    # Progress tracking and analytics
    └── profile_page.dart     # User profile and settings
```

### Backend (Python Flask)
- **Framework**: Flask 3.1.2
- **Port**: 8080 (not currently connected to frontend)
- **File**: main.py with basic demo routes

### Features Implemented

#### 1. Authentication Pages
- **Login Page**: Email/password fields, gradient background, navigation to signup
- **Signup Page**: Full name, email, password, confirm password fields with modern UI

#### 2. Dashboard (Home)
- Personalized greeting section
- Profile summary card (Weight, BMI, Calories burned)
- Today's workout section with action buttons
- Diet plan for the day (Breakfast, Lunch, Dinner cards)
- AI recommendation card

#### 3. Additional Pages
- **Workouts**: List of recommended workout programs
- **Diet**: Calorie tracking and meal planning
- **Progress**: Weekly activity summary and fitness metrics
- **Profile**: User information and settings

### Design Elements
- **Color Scheme**: Green (#4CAF50) and white for clean health vibe
- **UI Components**: Rounded corners (12px), gradient backgrounds, shadow effects
- **Icons**: Material Icons for all visual elements
- **Typography**: Roboto font family, bold headers, clear hierarchy

## Technology Stack
- **Frontend**: Flutter (Dart), Material Design 3
- **Backend**: Python Flask, Flask-CORS
- **Deployment**: Replit (Flutter web server on port 5000)

## Running the Project
The Flutter app automatically runs via the workflow:
```bash
cd nutrifit_app && flutter run -d web-server --web-hostname 0.0.0.0 --web-port 5000
```

To run the Flask backend separately (optional):
```bash
python main.py
```

## Future Enhancements
- Connect Flutter frontend to Flask backend API
- Implement actual user authentication
- Add workout tracking with timers
- Create interactive diet logging
- Build progress charts and analytics
- Integrate AI-powered recommendations
- Add database for data persistence
