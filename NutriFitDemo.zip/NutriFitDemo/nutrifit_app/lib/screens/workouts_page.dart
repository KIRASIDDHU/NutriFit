import 'package:flutter/material.dart';

class WorkoutsPage extends StatelessWidget {
  const WorkoutsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text('Workouts', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF4CAF50),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Recommended Workouts',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color(0xFF333333),
              ),
            ),
            const SizedBox(height: 16),
            _buildWorkoutCard(
              'Upper Body Strength',
              '45 min • Intermediate',
              Icons.fitness_center,
              const Color(0xFF4CAF50),
            ),
            const SizedBox(height: 12),
            _buildWorkoutCard(
              'Cardio Blast',
              '30 min • Beginner',
              Icons.directions_run,
              const Color(0xFFFF9800),
            ),
            const SizedBox(height: 12),
            _buildWorkoutCard(
              'Core & Abs',
              '20 min • All Levels',
              Icons.self_improvement,
              const Color(0xFF2196F3),
            ),
            const SizedBox(height: 12),
            _buildWorkoutCard(
              'Leg Day',
              '40 min • Advanced',
              Icons.accessibility_new,
              const Color(0xFF9C27B0),
            ),
            const SizedBox(height: 12),
            _buildWorkoutCard(
              'Yoga & Flexibility',
              '35 min • All Levels',
              Icons.spa,
              const Color(0xFF00BCD4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWorkoutCard(String title, String duration, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 32),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF333333),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  duration,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Color(0xFF666666),
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios, color: Color(0xFF999999), size: 20),
        ],
      ),
    );
  }
}
